
import baghchal.gui.PlayerImages;
import baghchal.gui.GameStatesMap;
import baghchal.logic.BaghChal;
import baghchal.logic.Selection;
import baghchal.logic.Player;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import baghchal.logic.BaghChalI;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;

public class GameMain extends Application {

	// game logic
	private BaghChal game = new BaghChal();

	// game tiles
	private Circle[][] tiles;

	// images of the players
	private final PlayerImages playerImages = new PlayerImages();

	// state messages
	private final GameStatesMap stateStrings = new GameStatesMap();

	
        // to display score information
	private Text goatsLeft;	
	private Text goatsEaten;        
        private Text tiggersTrapped;	       
	private Text state;

	/*
            TO create the game board
        */ 
	private Group boardGui() {
		GridPane grid = new GridPane();
		tiles = new Circle[BaghChalI.DIM][BaghChalI.DIM];
                    
		for (int x = 0; x < BaghChalI.DIM; x++) {
			for (int y = 0; y < BaghChalI.DIM; y++) {
				final int xPos = x;
				final int yPos = y;
				Circle c = new Circle(35.0);
				c.getStyleClass().add("tile");
				c.setOnMouseClicked(e -> {
					if (game.action(xPos, yPos)) {
						refresh();
					}
				});
				grid.add(c, x, y);
				tiles[x][y] = c;
				GridPane.setMargin(c, new Insets(16.0));
			}
		}

		Group group = new Group();
                // creating table 5x5
		for (int x = 0; x < BaghChalI.DIM; x++) {
			Line line = new Line();
                        line.setStroke(Color.RED);
                        line.setStrokeWidth(3);
			line.getStyleClass().add("fieldline");
			line.startXProperty().bind(tiles[x][0].layoutXProperty());
			line.startYProperty().bind(tiles[x][0].layoutYProperty());
			line.endXProperty().bind(tiles[x][4].layoutXProperty());
			line.endYProperty().bind(tiles[x][4].layoutYProperty());
			group.getChildren().add(line);
		}
                
		for (int x = 0; x < BaghChalI.DIM; x++) {
			Line line = new Line();
                        line.setStroke(Color.RED);
                        line.setStrokeWidth(3);
			line.getStyleClass().add("fieldline");
			line.startXProperty().bind(tiles[0][x].layoutXProperty());
			line.startYProperty().bind(tiles[0][x].layoutYProperty());
			line.endXProperty().bind(tiles[4][x].layoutXProperty());
			line.endYProperty().bind(tiles[4][x].layoutYProperty());
			group.getChildren().add(line);
		}
                // creating maze in between the table
		
                Line line1 = new Line();

                line1.setStroke(Color.RED);
                line1.setStrokeWidth(3);
                line1.startXProperty().bind(tiles[0][2].layoutXProperty());
                line1.startYProperty().bind(tiles[0][2].layoutYProperty());
                line1.endXProperty().bind(tiles[2][4].layoutXProperty());
                line1.endYProperty().bind(tiles[2][4].layoutYProperty());
                group.getChildren().add(line1);


                Line line2 = new Line();
                line2.setStroke(Color.RED);
                line2.setStrokeWidth(3);
                line2.startXProperty().bind(tiles[0][0].layoutXProperty());
                line2.startYProperty().bind(tiles[0][0].layoutYProperty());
                line2.endXProperty().bind(tiles[4][4].layoutXProperty());
                line2.endYProperty().bind(tiles[4][4].layoutYProperty());
                group.getChildren().add(line2);
		
		Line line3 = new Line();
                line3.setStroke(Color.RED);
                line3.setStrokeWidth(3);
                line3.startXProperty().bind(tiles[2][0].layoutXProperty());
                line3.startYProperty().bind(tiles[2][0].layoutYProperty());
                line3.endXProperty().bind(tiles[4][2].layoutXProperty());
                line3.endYProperty().bind(tiles[4][2].layoutYProperty());
                group.getChildren().add(line3);
		
                Line line4 = new Line();
                line4.setStroke(Color.RED);
                line4.setStrokeWidth(3);
                line4.startXProperty().bind(tiles[2][0].layoutXProperty());
                line4.startYProperty().bind(tiles[2][0].layoutYProperty());
                line4.endXProperty().bind(tiles[0][2].layoutXProperty());
                line4.endYProperty().bind(tiles[0][2].layoutYProperty());
                group.getChildren().add(line4);
		
                Line line5 = new Line();
                line5.setStroke(Color.RED);
                line5.setStrokeWidth(3);
                line5.startXProperty().bind(tiles[4][0].layoutXProperty());
                line5.startYProperty().bind(tiles[4][0].layoutYProperty());
                line5.endXProperty().bind(tiles[0][4].layoutXProperty());
                line5.endYProperty().bind(tiles[0][4].layoutYProperty());
                group.getChildren().add(line5);
		
                Line line6 = new Line();
                line6.setStroke(Color.RED);  
                line6.setStrokeWidth(3);
                line6.startXProperty().bind(tiles[4][2].layoutXProperty());
                line6.startYProperty().bind(tiles[4][2].layoutYProperty());
                line6.endXProperty().bind(tiles[2][4].layoutXProperty());
                line6.endYProperty().bind(tiles[2][4].layoutYProperty());
                group.getChildren().add(line6);
	

		group.getChildren().add(grid);

		return group;
	}

        
	private HBox gameOptions() {
                Button info = new Button("About"); 
                info.setTextAlignment(TextAlignment.CENTER);
		BorderPane box1 = new BorderPane(info);
                info.setOnAction(e -> {
                        //to show the reference website
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("About");
                        alert.setHeaderText("About:");
                        alert.setContentText("A multiplayer strategic board game\n\n"+
                                "Rules for tigers: \n" +
"They can move to an adjacent free position along the lines.\n" +
"They can capture goats during any move, and do not need to wait until all goats are placed.\n" +
"They can capture only one goat at a time.\n" +
"They can jump over a goat in any direction, as long as there is an open space for the tiger to complete its turn.\n" +
"A tiger cannot jump over another tiger.\n" +
"Rules for Goat: \n" +
"Goats cannot move until all goats have been positioned on the board.\n" +
"They must leave the board when captured.\n" +
"They cannot jump over tigers or other goats.");
                        alert.showAndWait();
                    }

                );
                
                Button reset= new Button("Reset"); 
                reset.setTextAlignment(TextAlignment.CENTER);
		BorderPane box2 = new BorderPane(reset);
                reset.setOnAction(e -> {
                        // new game
			game = new BaghChal();
			refresh();
		});
                
                Button close= new Button("Close"); 
                close.setTextAlignment(TextAlignment.CENTER);
		BorderPane box3 = new BorderPane(close);
                close.setOnAction(e -> {
                        //Close the application
			System.exit(0);
		});
                // to arange button in horizontal order
                HBox box0 = new HBox(box1, box2, box3);
                box0.setPadding(new Insets(2.0, 10.0, 2.0, 2.0));
                
		HBox.setHgrow(box1, Priority.ALWAYS);
		HBox.setHgrow(box2, Priority.ALWAYS);
                HBox.setHgrow(box3, Priority.ALWAYS);
		return box0;
	}

	//to display score
	private VBox scoreboard() {
                
		goatsLeft = new Text();
		goatsLeft.setFont(Font.font("Times new Roman", FontWeight.BOLD, FontPosture.ITALIC, 20.0));
		goatsLeft.setTextAlignment(TextAlignment.CENTER);
		BorderPane box1 = new BorderPane(goatsLeft);

		goatsEaten = new Text();
		goatsEaten.setFont(Font.font("Times new Roman", FontWeight.BOLD, FontPosture.ITALIC, 20.0));
		BorderPane box2 = new BorderPane(goatsEaten);
                
                
                tiggersTrapped = new Text();
                tiggersTrapped.setFont(Font.font("Times new Roman", FontWeight.BOLD, FontPosture.ITALIC, 20.0));
		BorderPane box3 = new BorderPane(tiggersTrapped);
                
                
                
                

		HBox box0 = new HBox(box1, box2, box3);
		box0.setPadding(new Insets(6.0, 0.0, 0.0, 0.0));
		HBox.setHgrow(box1, Priority.ALWAYS);
		HBox.setHgrow(box2, Priority.ALWAYS);
                HBox.setHgrow(box3, Priority.ALWAYS);

		state = new Text(stateStrings.get(game.getState()));
		state.setFont(Font.font("Times new Roman", FontWeight.BOLD, FontPosture.REGULAR, 25.0));
		BorderPane box4 = new BorderPane(state);
		box4.setPadding(new Insets(2.0, 0.0, 0.0, 0.0));

		return new VBox(new VBox(box0, box4));
	}
        // to refresh game board after each move
	protected void refresh() {

		Player[][] board = game.getBoard();
		// paint all tiles
		for (int x = 0; x < BaghChalI.DIM; x++) {
			for (int y = 0; y < BaghChalI.DIM; y++) {
                                 tiles[x][y].setFill(new ImagePattern(playerImages.get(board[x][y])));
				 tiles[x][y].setStroke(Color.TRANSPARENT);
                               
			}
		}

		// color selected
		Selection selected = game.getSelection();
		if (selected != null) {
			tiles[selected.row][selected.column].setStroke(Color.RED);
		}

		// set texts
		goatsLeft.setText("Goats left: " + game.getGoatsLeftToSet());
		goatsEaten.setText("Goats Killed: " + game.getGoatsEaten());
                
		state.setText("Turn:"+stateStrings.get(game.getState()));
                tiggersTrapped.setText("Tiggers Trapped: "+game.getTriggersTrapped());
                

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		VBox vBox = new VBox(scoreboard(), boardGui());
                
		BorderPane border = new BorderPane();
		border.setTop(gameOptions());
                border.setCenter(vBox);
                border.setBackground(Background.EMPTY);
                
		Scene scene = new Scene(border);
              
		primaryStage.setTitle("Bagh Chal");
                scene.setFill(Color.CHARTREUSE);
		primaryStage.setScene(scene);
   

		refresh();

		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
