package baghchal.gui;

import java.util.HashMap;

import baghchal.logic.Player;
import javafx.scene.image.Image;
/*
    Images of different player
*/

public class PlayerImages extends HashMap<Player, Image> {

        private final Image tigerLogo = new Image("resources/tiger-logo.png");
        private final Image goatLogo = new Image("resources/goat-logo.png");
        private final Image tLogo = new Image("resources/t-logo.png");
        
	/**
	 * Creates a new Color Fill Map.
	 */
	public PlayerImages() {
		super();
                
		put(Player.NONE, tLogo);
		put(Player.GOAT, goatLogo);
		put(Player.TIGER, tigerLogo);
	}

}
