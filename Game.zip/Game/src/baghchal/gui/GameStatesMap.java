package baghchal.gui;

import java.util.HashMap;

import baghchal.logic.BaghChalI.GameState;
/*
    Turn String based on the game state
*/
public class GameStatesMap extends HashMap<GameState, String> {

	public GameStatesMap() {
		super();
		put(GameState.GOAT_MOVE, "Goat");
		put(GameState.GOAT_SELECT, "Goat");
		put(GameState.GOAT_SET, "Goat");
		put(GameState.GOAT_WON, "Goat won!");
		put(GameState.TIGER_MOVE, "Tiger");
		put(GameState.TIGER_SELECT, "Tiger");
		put(GameState.TIGER_WON, "Tiger won!");
	}

}
