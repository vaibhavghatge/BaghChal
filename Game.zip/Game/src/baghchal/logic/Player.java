package baghchal.logic;
/*
    Game player types
*/
public enum Player { 
        GOAT,TIGER,NONE;
        
	public Player getPlayer() {
		switch (this) {
		case GOAT:
			return TIGER;
		case TIGER:
			return GOAT;
		case NONE:
			return NONE;
		default:
			return NONE;
		}
	}


	

}
