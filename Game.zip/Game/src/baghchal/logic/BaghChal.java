package baghchal.logic;

import java.util.Arrays;
/*
    Game logical contraints are implemented in this class
*/
public class BaghChal implements BaghChalI {
        
    
        // all possible movie from a particular tile
	private static final int[][] MOVES = {
            
                        //0  1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23 24
			{ 0, 1, 2, 0, 0, 1, 1, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 1, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 2, 1, 0, 1, 2, 0, 1, 1, 1, 0, 2, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 2, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 2, 1, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 1, 0, 0, 0, 0, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 1, 1, 1, 0, 0, 1, 0, 1, 2, 0, 1, 1, 1, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 1, 0, 0, 2, 1, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 1, 1, 1, 0, 2, 1, 0, 1, 0, 0, 1, 1, 1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0 },
			{ 2, 0, 2, 0, 0, 1, 1, 0, 0, 0, 0, 1, 2, 0, 0, 1, 1, 0, 0, 0, 2, 0, 2, 0, 0 },
			{ 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0 },
			{ 2, 0, 2, 0, 2, 0, 1, 1, 1, 0, 2, 1, 0, 1, 2, 0, 1, 1, 1, 0, 2, 0, 2, 0, 2 },
			{ 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0 },
			{ 0, 0, 2, 0, 2, 0, 0, 0, 1, 1, 0, 0, 2, 1, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 2 },
			{ 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 1, 1, 1, 0, 0, 1, 0, 1, 2, 0, 1, 1, 1, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 1, 2, 0, 0, 1, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 1, 1, 1, 0, 2, 1, 0, 1, 0, 0, 1, 1, 1 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 0, 0, 0, 0, 1 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 1, 1, 0, 0, 0, 0, 1, 2, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 2, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 2, 0, 1, 1, 1, 0, 2, 1, 0, 1, 2 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 1 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 1, 1, 0, 0, 2, 1, 0 } };

	// game board with players
	private Player[][] board;

	// got still available
	private int goatsLeftToSet;

	// no of gots tigers ate
	private int goatsEaten;

	// current selected tile
	private Selection selected;

	// current state of the game
	private GameState state;

        // creating game based
	public BaghChal() {
		board = new Player[DIM][DIM];
		for (int row = 0; row < DIM; row++) {
			for (int column = 0; column < DIM; column++) {
				board[row][column] = Player.NONE;
			}
		}
                //placing tigers in 4 corners
		board[0][0] = Player.TIGER;
		board[0][DIM - 1] = Player.TIGER;
		board[DIM - 1][DIM - 1] = Player.TIGER;
		board[DIM - 1][0] = Player.TIGER;
		goatsLeftToSet = TOTAL_GOATS;
		goatsEaten = 0;
		selected = null;
		state = GameState.GOAT_SET;
	
	}

	private BaghChal(BaghChal orig) {
		board = new Player[DIM][DIM];
		for (int row = 0; row < DIM; row++) {
			board[row] = orig.board[row].clone();
		}
		goatsLeftToSet = orig.goatsLeftToSet;
		goatsEaten = orig.goatsEaten;
		selected = null;
		state = orig.state;
		if (state == GameState.GOAT_MOVE) {
			state = GameState.GOAT_SELECT;
		}
		if (state == GameState.TIGER_MOVE) {
			state = GameState.TIGER_SELECT;
		}
		
	}
        // accessor methods
	@Override
	public Player[][] getBoard() {
		return board.clone();
	}

	@Override
	public int getGoatsEaten() {
		return goatsEaten;
	}

	@Override
	public int getGoatsLeftToSet() {
		return goatsLeftToSet;
	}

	@Override
	public Selection getSelection() {
		return selected;
	}

	@Override
	public GameState getState() {
		return state;
	}

	@Override
	public boolean action(int row, int column) {

                // game logic implementation based on the moves allowded
		switch (state) {
                // in case game is already over that is someone has won return false    
		case TIGER_WON:
			return false;

		case GOAT_WON:
			return false;
                // in case of goat is 
		case GOAT_SET:
			if (board[row][column] == Player.NONE) {
				// if place is empty allow setting the goat else return false
				board[row][column] = Player.GOAT;
				goatsLeftToSet--;
				switch (winnnerPlayer()) {
				case GOAT:
					state = GameState.GOAT_WON;
					return true;
				case TIGER:
					state = GameState.TIGER_WON;
					return true;
				case NONE:
					state = GameState.TIGER_SELECT;
					return true;
				default:
					throw new InternalError("Invalid Value");
				}
			}
			return false;
                        // for goat movement
		case GOAT_MOVE:
			switch (board[row][column]) {
			case GOAT:
				if ((selected.row == row) && (selected.column == column)) {
					selected = null;
					state = GameState.GOAT_SELECT;
					return true;
				} else {
					selected = new Selection(row, column);
					return true;
				}
			case TIGER:
				return false;
			case NONE:
				if ((getMovePossibility(selected.row, selected.column, row, column)) == 1) {
					
					board[selected.row][selected.column] = Player.NONE;
					board[row][column] = Player.GOAT;
					selected = null;
					switch (winnnerPlayer()) {
					case GOAT:
						state = GameState.GOAT_WON;
						return true;
					case TIGER:
						state = GameState.TIGER_WON;
						return true;
					case NONE:
						state = GameState.TIGER_SELECT;
						return true;
					default:
						throw new InternalError("Invalid Value");
					}
				}
				return false;
			default:
				throw new InternalError("Invalid Value");
			}
                     //for goat selection
		case GOAT_SELECT:
			if (board[row][column] == Player.GOAT) {
				selected = new Selection(row, column);
				state = GameState.GOAT_MOVE;
				return true;
			}
			return false;
                      // for tiger movement
		case TIGER_MOVE:
			switch (board[row][column]) {
			case GOAT:
				return false;
			case TIGER:
				if ((selected.row == row) && (selected.column == column)) {
					selected = null;
					state = GameState.TIGER_SELECT;
					return true;
				} else {
					selected = new Selection(row, column);
					return true;
				}
			case NONE:
				switch (getMovePossibility(selected.row, selected.column, row, column)) {
				case 0:
					return false;
				case 1:
					
					board[selected.row][selected.column] = Player.NONE;
					board[row][column] = Player.TIGER;
					selected = null;
					state = (goatsLeftToSet > 0) ? GameState.GOAT_SET : GameState.GOAT_SELECT;
					return true;
				case 2:
					int betweenRow = (selected.row + row) / 2;
					int betweenColumn = (selected.column + column) / 2;
					if (board[betweenRow][betweenColumn] != Player.GOAT) {
						return false;
					}
				
					board[selected.row][selected.column] = Player.NONE;
					board[betweenRow][betweenColumn] = Player.NONE;
					goatsEaten++;
					board[row][column] = Player.TIGER;
					selected = null;
					switch (winnnerPlayer()) {
					case GOAT:
						state = GameState.GOAT_WON;
						return true;
					case TIGER:
						state = GameState.TIGER_WON;
						return true;
					case NONE:
						state = (goatsLeftToSet > 0) ? GameState.GOAT_SET : GameState.GOAT_SELECT;
						return true;
					default:
						throw new InternalError("Invalid Value");
					}
				default:
					throw new InternalError("Invalid Value");
				}
			default:
				throw new InternalError("Invalid Value");
			}

		case TIGER_SELECT:
			if (board[row][column] == Player.TIGER) {
				selected = new Selection(row, column);
				state = GameState.TIGER_MOVE;
				return true;
			}
			return false;

		default:
			throw new InternalError("Invalid Value");
		}

	}

	@Override
	public BaghChal clone() {
		return new BaghChal(this);
	}

        
	private int getMovePossibility(int row, int column, int targetRow, int targetColumn) {
                // as the Dimensions of board is 5x5
		return MOVES[row * 5 + column][targetRow * 5 + targetColumn];
	}

	private boolean anyTigerCanMove() {
                // check for goat win 
		for (int row = 0; row < DIM; row++) {
			for (int column = 0; column < DIM; column++) {
				if ((board[row][column] == Player.TIGER) && tigerCanMove(row, column)) {
					return true;
				}
			}
		}
		return false;
	}


	private boolean tigerCanMove(int row, int column) {
                //check if a tiger can move or is trapped
		for (int targetRow = 0; targetRow < DIM; targetRow++) {
			for (int targetColumn = 0; targetColumn < DIM; targetColumn++) {
				int move = getMovePossibility(row, column, targetRow, targetColumn);
				if (move == 2 && board[targetRow][targetColumn] == Player.NONE
						&& board[(row + targetRow) / 2][(column + targetColumn) / 2] == Player.GOAT) {
					return true;
				}
				if (move == 1 && board[targetRow][targetColumn] == Player.NONE) {
					return true;
				}
			}
		}
		return false;
	}

        // return number of trapped tigers
         @Override
        public int getTriggersTrapped() {
            int free=4;
            for (int row = 0; row < DIM; row++) {
                            for (int column = 0; column < DIM; column++) {
                                    if ((board[row][column] == Player.TIGER) && !tigerCanMove(row, column)) {
                                            free--;
                                    }
                            }
                    }

            return 4-free;
        }
        
        // return the winning player if any else none
	private Player winnnerPlayer() {
		if (goatsEaten == TIGER_WIN_CONDITION) {
			return Player.TIGER;
		}
		if (!anyTigerCanMove()) {
			return Player.GOAT;
		}
		return Player.NONE;
	}


   

	
	

}
