package baghchal.logic;

/*
    Interface to logic part of the game
*/
public interface BaghChalI {


	public static final int DIM = 5;

	public static final int TOTAL_GOATS = 20;

	public static final int TIGER_WIN_CONDITION = 5;
        
        

	public Player[][] getBoard();

	public int getGoatsEaten();

	public int getGoatsLeftToSet();
        
        public int getTriggersTrapped();

	public boolean action(int row, int column);

	
	public Selection getSelection();

	public GameState getState();

	// game states 
	public enum GameState {

		GOAT_SET,
		TIGER_SELECT,
		TIGER_MOVE,
		GOAT_SELECT,
		GOAT_MOVE,
		GOAT_WON,
		TIGER_WON;

	}

  

	

}
